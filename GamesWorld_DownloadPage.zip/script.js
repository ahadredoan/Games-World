const textElement = document.getElementById('text');
const phrases = [
  '⬇️ Download Now!',
  '🛡 Safe & Fast apk',
  '🚀 Ready to Install'
];
let i = 0;
setInterval(() => {
  textElement.innerHTML = phrases[i];
  i = (i + 1) % phrases.length;
}, 2500);
